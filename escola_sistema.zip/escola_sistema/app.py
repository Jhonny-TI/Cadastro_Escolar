# -*- coding: utf-8 -*-
"""
Sistema de Gestão Escolar
==========================
Cadastro de alunos e professores, controle de presenças/faltas,
lançamento de notas, boletim, histórico escolar e reconhecimento
facial por IA (OpenCV) para identificar pessoas cadastradas por
foto (upload ou webcam).

Para rodar:
    pip install -r requirements.txt
    python app.py
Acesse http://localhost:5000  (login padrão: admin / admin123)
"""
import os
import functools
from datetime import datetime

from flask import (Flask, render_template, request, redirect, url_for,
                    session, flash, jsonify, send_from_directory)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

import db
import face_utils

app = Flask(__name__)
app.secret_key = 'troque-esta-chave-em-producao-por-uma-aleatoria'
app.config['MAX_CONTENT_LENGTH'] = 20 * 1024 * 1024  # 20MB (fotos)

db.init_app(app)


# ---------------------------------------------------------------------------
# Autenticação
# ---------------------------------------------------------------------------
def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get('user_id'):
            flash('Faça login para continuar.', 'warning')
            return redirect(url_for('login'))
        return view(*args, **kwargs)
    return wrapped


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        senha = request.form['senha']
        conn = db.get_db()
        user = conn.execute('SELECT * FROM usuarios WHERE username = ?', (username,)).fetchone()
        if user and check_password_hash(user['senha_hash'], senha):
            session.clear()
            session['user_id'] = user['id']
            session['user_nome'] = user['nome']
            flash(f'Bem-vindo, {user["nome"]}!', 'success')
            return redirect(url_for('dashboard'))
        flash('Usuário ou senha inválidos.', 'danger')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Você saiu do sistema.', 'info')
    return redirect(url_for('login'))


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@app.route('/')
@login_required
def dashboard():
    conn = db.get_db()
    total_alunos = conn.execute('SELECT COUNT(*) c FROM alunos WHERE ativo=1').fetchone()['c']
    total_professores = conn.execute('SELECT COUNT(*) c FROM professores WHERE ativo=1').fetchone()['c']
    total_turmas = conn.execute('SELECT COUNT(*) c FROM turmas').fetchone()['c']
    total_disciplinas = conn.execute('SELECT COUNT(*) c FROM disciplinas').fetchone()['c']
    hoje = datetime.now().strftime('%Y-%m-%d')
    presencas_hoje = conn.execute('SELECT COUNT(*) c FROM presencas WHERE data = ? AND presente=1', (hoje,)).fetchone()['c']
    faltas_hoje = conn.execute('SELECT COUNT(*) c FROM presencas WHERE data = ? AND presente=0', (hoje,)).fetchone()['c']
    return render_template('dashboard.html',
                            total_alunos=total_alunos,
                            total_professores=total_professores,
                            total_turmas=total_turmas,
                            total_disciplinas=total_disciplinas,
                            presencas_hoje=presencas_hoje,
                            faltas_hoje=faltas_hoje)


# ---------------------------------------------------------------------------
# Helpers de foto/IA
# ---------------------------------------------------------------------------
def processar_fotos_cadastro(tipo, pessoa_id):
    """Lê arquivos do input 'fotos' e capturas da webcam (campo 'capturas') do form atual,
    salva rostos detectados e re-treina o modelo. Retorna quantidade de rostos salvos."""
    arquivos_bytes = []
    for f in request.files.getlist('fotos'):
        if f and f.filename:
            arquivos_bytes.append(f.read())

    capturas_json = request.form.get('capturas')
    capturas = []
    if capturas_json:
        import json
        try:
            capturas = json.loads(capturas_json)
        except Exception:
            capturas = []

    salvos = face_utils.salvar_fotos(tipo, pessoa_id, arquivos_bytes, capturas)
    if salvos > 0:
        face_utils.treinar_modelo(db.DB_PATH)
    return salvos


# ---------------------------------------------------------------------------
# ALUNOS
# ---------------------------------------------------------------------------
@app.route('/alunos')
@login_required
def alunos_lista():
    conn = db.get_db()
    busca = request.args.get('q', '').strip()
    if busca:
        alunos = conn.execute('''
            SELECT a.*, t.nome as turma_nome FROM alunos a
            LEFT JOIN turmas t ON a.turma_id = t.id
            WHERE a.ativo=1 AND (a.nome LIKE ? OR a.matricula LIKE ? OR a.cpf LIKE ?)
            ORDER BY a.nome''', (f'%{busca}%', f'%{busca}%', f'%{busca}%')).fetchall()
    else:
        alunos = conn.execute('''
            SELECT a.*, t.nome as turma_nome FROM alunos a
            LEFT JOIN turmas t ON a.turma_id = t.id
            WHERE a.ativo=1 ORDER BY a.nome''').fetchall()
    return render_template('alunos_lista.html', alunos=alunos, busca=busca)


@app.route('/alunos/cadastrar', methods=['GET', 'POST'])
@login_required
def alunos_cadastrar():
    conn = db.get_db()
    turmas = conn.execute('SELECT * FROM turmas ORDER BY nome').fetchall()

    if request.method == 'POST':
        nome = request.form['nome'].strip()
        cpf = request.form.get('cpf', '').strip() or None
        matricula = request.form.get('matricula', '').strip()
        if not matricula:
            matricula = 'A' + datetime.now().strftime('%Y%m%d%H%M%S')
        data_nascimento = request.form.get('data_nascimento') or None
        email = request.form.get('email', '').strip() or None
        telefone = request.form.get('telefone', '').strip() or None
        responsavel = request.form.get('responsavel', '').strip() or None
        telefone_responsavel = request.form.get('telefone_responsavel', '').strip() or None
        turma_id = request.form.get('turma_id') or None

        try:
            cur = conn.execute('''
                INSERT INTO alunos (nome, cpf, matricula, data_nascimento, email, telefone,
                                     responsavel, telefone_responsavel, turma_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (nome, cpf, matricula, data_nascimento, email, telefone,
                  responsavel, telefone_responsavel, turma_id))
            conn.commit()
            aluno_id = cur.lastrowid

            salvos = processar_fotos_cadastro('aluno', aluno_id)
            if salvos:
                foto_path = face_utils.primeira_foto_perfil('aluno', aluno_id)
                conn.execute('UPDATE alunos SET foto_path=? WHERE id=?', (foto_path, aluno_id))
                conn.commit()

            # matricula automaticamente em todas as disciplinas vinculadas à turma
            if turma_id:
                disciplinas_turma = conn.execute(
                    'SELECT DISTINCT disciplina_id FROM professor_disciplina WHERE turma_id=?',
                    (turma_id,)).fetchall()
                ano = datetime.now().year
                for d in disciplinas_turma:
                    conn.execute('''INSERT INTO matriculas (aluno_id, disciplina_id, turma_id, ano_letivo)
                                     VALUES (?, ?, ?, ?)''', (aluno_id, d['disciplina_id'], turma_id, ano))
                conn.commit()

            msg = f'Aluno "{nome}" cadastrado com sucesso! Matrícula: {matricula}.'
            if salvos:
                msg += f' ({salvos} foto(s) usada(s) para reconhecimento facial.)'
            else:
                msg += ' Nenhuma foto válida foi enviada para o reconhecimento facial.'
            flash(msg, 'success')
            return redirect(url_for('alunos_lista'))
        except Exception as e:
            conn.rollback()
            flash(f'Erro ao cadastrar aluno: {e}', 'danger')

    return render_template('alunos_cadastro.html', turmas=turmas)


@app.route('/alunos/<int:aluno_id>')
@login_required
def aluno_detalhe(aluno_id):
    conn = db.get_db()
    aluno = conn.execute('''SELECT a.*, t.nome as turma_nome FROM alunos a
                             LEFT JOIN turmas t ON a.turma_id=t.id WHERE a.id=?''', (aluno_id,)).fetchone()
    if not aluno:
        flash('Aluno não encontrado.', 'danger')
        return redirect(url_for('alunos_lista'))

    faltas = conn.execute('SELECT COUNT(*) c FROM presencas WHERE aluno_id=? AND presente=0', (aluno_id,)).fetchone()['c']
    presencas = conn.execute('SELECT COUNT(*) c FROM presencas WHERE aluno_id=? AND presente=1', (aluno_id,)).fetchone()['c']
    total_registros = faltas + presencas
    freq = round((presencas / total_registros) * 100, 1) if total_registros else 100.0

    notas_recentes = conn.execute('''
        SELECT n.*, d.nome as disciplina_nome FROM notas n
        JOIN disciplinas d ON n.disciplina_id = d.id
        WHERE n.aluno_id=? ORDER BY n.ano_letivo DESC, n.bimestre DESC LIMIT 6''', (aluno_id,)).fetchall()

    return render_template('aluno_detalhe.html', aluno=aluno, faltas=faltas, presencas=presencas,
                            freq=freq, notas_recentes=notas_recentes)


@app.route('/alunos/<int:aluno_id>/excluir', methods=['POST'])
@login_required
def aluno_excluir(aluno_id):
    conn = db.get_db()
    conn.execute('UPDATE alunos SET ativo=0 WHERE id=?', (aluno_id,))
    conn.commit()
    flash('Aluno removido (inativado) com sucesso.', 'info')
    return redirect(url_for('alunos_lista'))


# ---------------------------------------------------------------------------
# PROFESSORES
# ---------------------------------------------------------------------------
@app.route('/professores')
@login_required
def professores_lista():
    conn = db.get_db()
    busca = request.args.get('q', '').strip()
    if busca:
        professores = conn.execute('''SELECT * FROM professores WHERE ativo=1 AND
            (nome LIKE ? OR registro LIKE ? OR cpf LIKE ?) ORDER BY nome''',
            (f'%{busca}%', f'%{busca}%', f'%{busca}%')).fetchall()
    else:
        professores = conn.execute('SELECT * FROM professores WHERE ativo=1 ORDER BY nome').fetchall()
    return render_template('professores_lista.html', professores=professores, busca=busca)


@app.route('/professores/cadastrar', methods=['GET', 'POST'])
@login_required
def professores_cadastrar():
    conn = db.get_db()
    disciplinas = conn.execute('SELECT * FROM disciplinas ORDER BY nome').fetchall()
    turmas = conn.execute('SELECT * FROM turmas ORDER BY nome').fetchall()

    if request.method == 'POST':
        nome = request.form['nome'].strip()
        cpf = request.form.get('cpf', '').strip() or None
        registro = request.form.get('registro', '').strip()
        if not registro:
            registro = 'P' + datetime.now().strftime('%Y%m%d%H%M%S')
        email = request.form.get('email', '').strip() or None
        telefone = request.form.get('telefone', '').strip() or None
        especialidade = request.form.get('especialidade', '').strip() or None
        data_nascimento = request.form.get('data_nascimento') or None

        try:
            cur = conn.execute('''INSERT INTO professores (nome, cpf, registro, email, telefone,
                                   especialidade, data_nascimento) VALUES (?, ?, ?, ?, ?, ?, ?)''',
                                (nome, cpf, registro, email, telefone, especialidade, data_nascimento))
            conn.commit()
            professor_id = cur.lastrowid

            salvos = processar_fotos_cadastro('professor', professor_id)
            if salvos:
                foto_path = face_utils.primeira_foto_perfil('professor', professor_id)
                conn.execute('UPDATE professores SET foto_path=? WHERE id=?', (foto_path, professor_id))
                conn.commit()

            # vínculos disciplina/turma
            disciplina_ids = request.form.getlist('disciplina_id')
            turma_ids = request.form.getlist('turma_id')
            for did in disciplina_ids:
                for tid in turma_ids:
                    conn.execute('''INSERT INTO professor_disciplina (professor_id, disciplina_id, turma_id)
                                     VALUES (?, ?, ?)''', (professor_id, did, tid))
            conn.commit()

            msg = f'Professor(a) "{nome}" cadastrado(a) com sucesso! Registro: {registro}.'
            if salvos:
                msg += f' ({salvos} foto(s) usada(s) para reconhecimento facial.)'
            flash(msg, 'success')
            return redirect(url_for('professores_lista'))
        except Exception as e:
            conn.rollback()
            flash(f'Erro ao cadastrar professor: {e}', 'danger')

    return render_template('professores_cadastro.html', disciplinas=disciplinas, turmas=turmas)


@app.route('/professores/<int:professor_id>')
@login_required
def professor_detalhe(professor_id):
    conn = db.get_db()
    professor = conn.execute('SELECT * FROM professores WHERE id=?', (professor_id,)).fetchone()
    if not professor:
        flash('Professor não encontrado.', 'danger')
        return redirect(url_for('professores_lista'))
    vinculos = conn.execute('''
        SELECT pd.*, d.nome as disciplina_nome, t.nome as turma_nome FROM professor_disciplina pd
        JOIN disciplinas d ON pd.disciplina_id = d.id
        JOIN turmas t ON pd.turma_id = t.id
        WHERE pd.professor_id=?''', (professor_id,)).fetchall()
    return render_template('professor_detalhe.html', professor=professor, vinculos=vinculos)


@app.route('/professores/<int:professor_id>/excluir', methods=['POST'])
@login_required
def professor_excluir(professor_id):
    conn = db.get_db()
    conn.execute('UPDATE professores SET ativo=0 WHERE id=?', (professor_id,))
    conn.commit()
    flash('Professor removido (inativado) com sucesso.', 'info')
    return redirect(url_for('professores_lista'))


# ---------------------------------------------------------------------------
# TURMAS E DISCIPLINAS
# ---------------------------------------------------------------------------
@app.route('/turmas', methods=['GET', 'POST'])
@login_required
def turmas():
    conn = db.get_db()
    if request.method == 'POST':
        nome = request.form['nome'].strip()
        ano_letivo = request.form['ano_letivo']
        turno = request.form.get('turno')
        conn.execute('INSERT INTO turmas (nome, ano_letivo, turno) VALUES (?, ?, ?)', (nome, ano_letivo, turno))
        conn.commit()
        flash(f'Turma "{nome}" cadastrada com sucesso!', 'success')
        return redirect(url_for('turmas'))
    lista = conn.execute('SELECT * FROM turmas ORDER BY ano_letivo DESC, nome').fetchall()
    return render_template('turmas.html', turmas=lista)


@app.route('/disciplinas', methods=['GET', 'POST'])
@login_required
def disciplinas():
    conn = db.get_db()
    if request.method == 'POST':
        nome = request.form['nome'].strip()
        carga_horaria = request.form.get('carga_horaria') or None
        conn.execute('INSERT INTO disciplinas (nome, carga_horaria) VALUES (?, ?)', (nome, carga_horaria))
        conn.commit()
        flash(f'Disciplina "{nome}" cadastrada com sucesso!', 'success')
        return redirect(url_for('disciplinas'))
    lista = conn.execute('SELECT * FROM disciplinas ORDER BY nome').fetchall()
    return render_template('disciplinas.html', disciplinas=lista)


# ---------------------------------------------------------------------------
# PRESENÇA / FALTAS
# ---------------------------------------------------------------------------
@app.route('/presenca', methods=['GET', 'POST'])
@login_required
def presenca():
    conn = db.get_db()
    turmas = conn.execute('SELECT * FROM turmas ORDER BY nome').fetchall()
    disciplinas = conn.execute('SELECT * FROM disciplinas ORDER BY nome').fetchall()

    turma_id = request.values.get('turma_id')
    disciplina_id = request.values.get('disciplina_id')
    data_aula = request.values.get('data_aula') or datetime.now().strftime('%Y-%m-%d')

    alunos = []
    if turma_id:
        alunos = conn.execute('SELECT * FROM alunos WHERE turma_id=? AND ativo=1 ORDER BY nome', (turma_id,)).fetchall()

    if request.method == 'POST' and turma_id and disciplina_id:
        for aluno in alunos:
            presente = 1 if request.form.get(f'presente_{aluno["id"]}') else 0
            existente = conn.execute('''SELECT id FROM presencas WHERE aluno_id=? AND disciplina_id=? AND data=?''',
                                      (aluno['id'], disciplina_id, data_aula)).fetchone()
            if existente:
                conn.execute('UPDATE presencas SET presente=?, metodo=? WHERE id=?',
                             (presente, 'manual', existente['id']))
            else:
                conn.execute('''INSERT INTO presencas (aluno_id, disciplina_id, data, presente, metodo)
                                 VALUES (?, ?, ?, ?, ?)''', (aluno['id'], disciplina_id, data_aula, presente, 'manual'))
        conn.commit()
        flash('Chamada registrada com sucesso!', 'success')
        return redirect(url_for('presenca', turma_id=turma_id, disciplina_id=disciplina_id, data_aula=data_aula))

    presencas_marcadas = {}
    if turma_id and disciplina_id:
        rows = conn.execute('SELECT aluno_id, presente FROM presencas WHERE disciplina_id=? AND data=?',
                             (disciplina_id, data_aula)).fetchall()
        presencas_marcadas = {r['aluno_id']: r['presente'] for r in rows}

    return render_template('presenca.html', turmas=turmas, disciplinas=disciplinas, alunos=alunos,
                            turma_id=turma_id, disciplina_id=disciplina_id, data_aula=data_aula,
                            presencas_marcadas=presencas_marcadas)


@app.route('/presenca/reconhecimento', methods=['GET', 'POST'])
@login_required
def presenca_reconhecimento():
    conn = db.get_db()
    disciplinas = conn.execute('SELECT * FROM disciplinas ORDER BY nome').fetchall()
    return render_template('presenca_reconhecimento.html', disciplinas=disciplinas)


@app.route('/api/presenca/reconhecer', methods=['POST'])
@login_required
def api_presenca_reconhecer():
    """Recebe uma imagem (base64) da webcam, identifica o aluno e marca presença."""
    data = request.get_json(silent=True) or {}
    imagem_b64 = data.get('imagem')
    disciplina_id = data.get('disciplina_id')
    data_aula = data.get('data_aula') or datetime.now().strftime('%Y-%m-%d')

    if not imagem_b64 or not disciplina_id:
        return jsonify({'ok': False, 'erro': 'Dados incompletos.'}), 400

    img = face_utils.decode_base64_image(imagem_b64)
    resultado = face_utils.reconhecer(img, db.DB_PATH)

    if not resultado.get('encontrado'):
        motivo = resultado.get('motivo', 'desconhecido')
        mensagens = {
            'sem_modelo': 'Nenhuma pessoa foi cadastrada com fotos para o reconhecimento facial ainda.',
            'sem_rosto': 'Nenhum rosto detectado na imagem. Tente novamente com melhor iluminação.',
            'desconhecido': 'Rosto não reconhecido como nenhum aluno/professor cadastrado.'
        }
        return jsonify({'ok': False, 'erro': mensagens.get(motivo, 'Não foi possível reconhecer.')})

    if resultado['tipo'] != 'aluno':
        conn2 = db.get_db()
        prof = conn2.execute('SELECT nome FROM professores WHERE id=?', (resultado['pessoa_id'],)).fetchone()
        nome = prof['nome'] if prof else 'Professor desconhecido'
        return jsonify({'ok': True, 'tipo': 'professor', 'nome': nome,
                         'confianca': resultado['confianca'],
                         'mensagem': f'Reconhecido: professor(a) {nome}. Presenças são registradas apenas para alunos.'})

    aluno_id = resultado['pessoa_id']
    aluno = conn.execute('SELECT * FROM alunos WHERE id=?', (aluno_id,)).fetchone()
    if not aluno:
        return jsonify({'ok': False, 'erro': 'Aluno associado não encontrado no banco.'})

    existente = conn.execute('SELECT id FROM presencas WHERE aluno_id=? AND disciplina_id=? AND data=?',
                              (aluno_id, disciplina_id, data_aula)).fetchone()
    if existente:
        conn.execute('UPDATE presencas SET presente=1, metodo=? WHERE id=?', ('facial', existente['id']))
    else:
        conn.execute('''INSERT INTO presencas (aluno_id, disciplina_id, data, presente, metodo)
                         VALUES (?, ?, ?, 1, ?)''', (aluno_id, disciplina_id, data_aula, 'facial'))
    conn.commit()

    return jsonify({'ok': True, 'tipo': 'aluno', 'nome': aluno['nome'], 'matricula': aluno['matricula'],
                     'confianca': resultado['confianca'],
                     'mensagem': f'Presença registrada para {aluno["nome"]} (matrícula {aluno["matricula"]}).'})


# ---------------------------------------------------------------------------
# NOTAS / BOLETIM / HISTÓRICO
# ---------------------------------------------------------------------------
@app.route('/notas/lancar', methods=['GET', 'POST'])
@login_required
def notas_lancar():
    conn = db.get_db()
    turmas = conn.execute('SELECT * FROM turmas ORDER BY nome').fetchall()
    disciplinas = conn.execute('SELECT * FROM disciplinas ORDER BY nome').fetchall()

    turma_id = request.values.get('turma_id')
    disciplina_id = request.values.get('disciplina_id')
    bimestre = request.values.get('bimestre', '1')
    ano_letivo = request.values.get('ano_letivo', str(datetime.now().year))

    alunos = []
    if turma_id:
        alunos = conn.execute('SELECT * FROM alunos WHERE turma_id=? AND ativo=1 ORDER BY nome', (turma_id,)).fetchall()

    if request.method == 'POST' and turma_id and disciplina_id:
        for aluno in alunos:
            valor = request.form.get(f'nota_{aluno["id"]}', '').strip()
            if valor == '':
                continue
            try:
                nota = float(valor.replace(',', '.'))
            except ValueError:
                continue
            existente = conn.execute('''SELECT id FROM notas WHERE aluno_id=? AND disciplina_id=?
                                         AND bimestre=? AND ano_letivo=?''',
                                      (aluno['id'], disciplina_id, bimestre, ano_letivo)).fetchone()
            if existente:
                conn.execute('UPDATE notas SET nota=? WHERE id=?', (nota, existente['id']))
            else:
                conn.execute('''INSERT INTO notas (aluno_id, disciplina_id, bimestre, nota, ano_letivo)
                                 VALUES (?, ?, ?, ?, ?)''', (aluno['id'], disciplina_id, bimestre, nota, ano_letivo))
        conn.commit()
        flash('Notas lançadas com sucesso!', 'success')
        return redirect(url_for('notas_lancar', turma_id=turma_id, disciplina_id=disciplina_id,
                                 bimestre=bimestre, ano_letivo=ano_letivo))

    notas_atuais = {}
    if turma_id and disciplina_id:
        rows = conn.execute('''SELECT aluno_id, nota FROM notas WHERE disciplina_id=? AND bimestre=? AND ano_letivo=?''',
                             (disciplina_id, bimestre, ano_letivo)).fetchall()
        notas_atuais = {r['aluno_id']: r['nota'] for r in rows}

    return render_template('notas_lancar.html', turmas=turmas, disciplinas=disciplinas, alunos=alunos,
                            turma_id=turma_id, disciplina_id=disciplina_id, bimestre=bimestre,
                            ano_letivo=ano_letivo, notas_atuais=notas_atuais)


@app.route('/boletim/<int:aluno_id>')
@login_required
def boletim(aluno_id):
    conn = db.get_db()
    aluno = conn.execute('SELECT * FROM alunos WHERE id=?', (aluno_id,)).fetchone()
    if not aluno:
        flash('Aluno não encontrado.', 'danger')
        return redirect(url_for('alunos_lista'))

    ano_letivo = request.args.get('ano_letivo', str(datetime.now().year))

    disciplinas = conn.execute('''
        SELECT DISTINCT d.* FROM matriculas m JOIN disciplinas d ON m.disciplina_id=d.id
        WHERE m.aluno_id=? AND m.ano_letivo=? ORDER BY d.nome''', (aluno_id, ano_letivo)).fetchall()

    boletim_data = []
    for d in disciplinas:
        notas = conn.execute('''SELECT bimestre, nota FROM notas WHERE aluno_id=? AND disciplina_id=?
                                 AND ano_letivo=? ORDER BY bimestre''', (aluno_id, d['id'], ano_letivo)).fetchall()
        notas_dict = {n['bimestre']: n['nota'] for n in notas}
        valores = [v for v in notas_dict.values()]
        media = round(sum(valores) / len(valores), 1) if valores else None

        faltas = conn.execute('SELECT COUNT(*) c FROM presencas WHERE aluno_id=? AND disciplina_id=? AND presente=0',
                               (aluno_id, d['id'])).fetchone()['c']
        presencas_c = conn.execute('SELECT COUNT(*) c FROM presencas WHERE aluno_id=? AND disciplina_id=? AND presente=1',
                                    (aluno_id, d['id'])).fetchone()['c']
        total = faltas + presencas_c
        freq = round((presencas_c / total) * 100, 1) if total else 100.0

        situacao = 'Cursando'
        if media is not None:
            if media >= 6 and freq >= 75:
                situacao = 'Aprovado'
            elif freq < 75:
                situacao = 'Reprovado por Falta'
            else:
                situacao = 'Reprovado'

        boletim_data.append({
            'disciplina': d['nome'],
            'notas': notas_dict,
            'media': media,
            'faltas': faltas,
            'frequencia': freq,
            'situacao': situacao
        })

    anos = conn.execute('SELECT DISTINCT ano_letivo FROM matriculas WHERE aluno_id=? ORDER BY ano_letivo DESC',
                         (aluno_id,)).fetchall()

    return render_template('boletim.html', aluno=aluno, boletim_data=boletim_data,
                            ano_letivo=ano_letivo, anos=[a['ano_letivo'] for a in anos])


@app.route('/historico/<int:aluno_id>')
@login_required
def historico(aluno_id):
    conn = db.get_db()
    aluno = conn.execute('''SELECT a.*, t.nome as turma_nome FROM alunos a
                             LEFT JOIN turmas t ON a.turma_id=t.id WHERE a.id=?''', (aluno_id,)).fetchone()
    if not aluno:
        flash('Aluno não encontrado.', 'danger')
        return redirect(url_for('alunos_lista'))

    anos = conn.execute('SELECT DISTINCT ano_letivo FROM matriculas WHERE aluno_id=? ORDER BY ano_letivo',
                         (aluno_id,)).fetchall()

    historico_por_ano = []
    for a in anos:
        ano = a['ano_letivo']
        disciplinas = conn.execute('''SELECT DISTINCT d.* FROM matriculas m JOIN disciplinas d ON m.disciplina_id=d.id
                                       WHERE m.aluno_id=? AND m.ano_letivo=? ORDER BY d.nome''', (aluno_id, ano)).fetchall()
        linhas = []
        for d in disciplinas:
            notas = conn.execute('''SELECT nota FROM notas WHERE aluno_id=? AND disciplina_id=? AND ano_letivo=?''',
                                  (aluno_id, d['id'], ano)).fetchall()
            valores = [n['nota'] for n in notas]
            media = round(sum(valores) / len(valores), 1) if valores else None
            faltas = conn.execute('SELECT COUNT(*) c FROM presencas WHERE aluno_id=? AND disciplina_id=? AND presente=0',
                                   (aluno_id, d['id'])).fetchone()['c']
            situacao = 'Cursando'
            if media is not None:
                situacao = 'Aprovado' if media >= 6 else 'Reprovado'
            linhas.append({'disciplina': d['nome'], 'media': media, 'faltas': faltas, 'situacao': situacao})
        historico_por_ano.append({'ano': ano, 'linhas': linhas})

    total_faltas = conn.execute('SELECT COUNT(*) c FROM presencas WHERE aluno_id=? AND presente=0', (aluno_id,)).fetchone()['c']

    return render_template('historico.html', aluno=aluno, historico_por_ano=historico_por_ano, total_faltas=total_faltas)


# ---------------------------------------------------------------------------
# RECONHECIMENTO FACIAL (página geral de identificação)
# ---------------------------------------------------------------------------
@app.route('/reconhecimento')
@login_required
def reconhecimento():
    return render_template('reconhecimento.html')


@app.route('/api/reconhecer', methods=['POST'])
@login_required
def api_reconhecer():
    """Identifica quem está na foto (aluno ou professor), sem marcar presença."""
    imagem_b64 = None
    img = None

    if request.is_json:
        data = request.get_json(silent=True) or {}
        imagem_b64 = data.get('imagem')
        if imagem_b64:
            img = face_utils.decode_base64_image(imagem_b64)
    elif 'foto' in request.files:
        f = request.files['foto']
        import numpy as np, cv2
        arr = np.frombuffer(f.read(), dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)

    if img is None:
        return jsonify({'ok': False, 'erro': 'Nenhuma imagem recebida.'}), 400

    resultado = face_utils.reconhecer(img, db.DB_PATH)
    if not resultado.get('encontrado'):
        motivo = resultado.get('motivo', 'desconhecido')
        mensagens = {
            'sem_modelo': 'Nenhuma pessoa foi cadastrada com fotos para reconhecimento facial ainda.',
            'sem_rosto': 'Nenhum rosto detectado na imagem enviada.',
            'desconhecido': 'Pessoa não identificada no banco de dados.'
        }
        return jsonify({'ok': False, 'erro': mensagens.get(motivo, 'Não reconhecido.')})

    conn = db.get_db()
    if resultado['tipo'] == 'aluno':
        p = conn.execute('SELECT * FROM alunos WHERE id=?', (resultado['pessoa_id'],)).fetchone()
        return jsonify({'ok': True, 'tipo': 'Aluno', 'nome': p['nome'], 'identificacao': p['matricula'],
                         'confianca': resultado['confianca'], 'id': p['id']})
    else:
        p = conn.execute('SELECT * FROM professores WHERE id=?', (resultado['pessoa_id'],)).fetchone()
        return jsonify({'ok': True, 'tipo': 'Professor', 'nome': p['nome'], 'identificacao': p['registro'],
                         'confianca': resultado['confianca'], 'id': p['id']})


# ---------------------------------------------------------------------------
# Arquivos estáticos de fotos
# ---------------------------------------------------------------------------
@app.route('/static/faces/<path:filename>')
def faces_file(filename):
    return send_from_directory(os.path.join(app.root_path, 'static', 'faces'), filename)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
