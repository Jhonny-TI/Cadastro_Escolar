"""
Módulo de IA para reconhecimento facial.

Usa o OpenCV para:
1. Detectar rostos em imagens (Haar Cascade).
2. Treinar um modelo de reconhecimento (LBPH - Local Binary Patterns Histograms)
   com as fotos cadastradas de cada aluno/professor.
3. Identificar quem é a pessoa em uma nova foto (tirada na hora ou upada).

O modelo é re-treinado automaticamente sempre que um novo cadastro de foto
é realizado, e os rótulos (labels) numéricos são mapeados para (tipo, pessoa_id)
na tabela face_labels do banco de dados.
"""
import os
import cv2
import numpy as np
import base64
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FACES_DIR = os.path.join(BASE_DIR, 'static', 'faces')
MODEL_PATH = os.path.join(BASE_DIR, 'instance', 'recognizer.yml')

_cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
face_cascade = cv2.CascadeClassifier(_cascade_path)

FACE_SIZE = (200, 200)
CONFIANCA_MAXIMA = 75  # quanto MENOR, mais parecido (distância LBPH). Acima disso = desconhecido


def _pessoa_dir(tipo, pessoa_id):
    d = os.path.join(FACES_DIR, f'{tipo}_{pessoa_id}')
    os.makedirs(d, exist_ok=True)
    return d


def _decode_base64_image(b64str):
    """Converte uma string base64 (data URL da webcam) em imagem OpenCV (BGR)."""
    if ',' in b64str:
        b64str = b64str.split(',', 1)[1]
    img_bytes = base64.b64decode(b64str)
    arr = np.frombuffer(img_bytes, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    return img


def detectar_rosto(img_bgr):
    """Retorna o recorte em tons de cinza do maior rosto encontrado na imagem, ou None."""
    if img_bgr is None:
        return None
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(60, 60))
    if len(faces) == 0:
        return None
    # pega o maior rosto detectado
    faces = sorted(faces, key=lambda f: f[2] * f[3], reverse=True)
    (x, y, w, h) = faces[0]
    rosto = gray[y:y + h, x:x + w]
    rosto = cv2.resize(rosto, FACE_SIZE)
    return rosto


def salvar_fotos(tipo, pessoa_id, arquivos_bytes=None, capturas_base64=None):
    """
    Salva fotos (de upload ou webcam) recortando o rosto detectado.
    arquivos_bytes: lista de bytes de arquivos de imagem enviados por upload.
    capturas_base64: lista de strings base64 (data URL) tiradas pela webcam.
    Retorna a quantidade de rostos válidos salvos.
    """
    pasta = _pessoa_dir(tipo, pessoa_id)
    existentes = len([f for f in os.listdir(pasta) if f.endswith('.jpg')])
    salvos = 0

    imagens = []
    if arquivos_bytes:
        for b in arquivos_bytes:
            arr = np.frombuffer(b, dtype=np.uint8)
            img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            if img is not None:
                imagens.append(img)
    if capturas_base64:
        for b64 in capturas_base64:
            img = _decode_base64_image(b64)
            if img is not None:
                imagens.append(img)

    for img in imagens:
        rosto = detectar_rosto(img)
        if rosto is not None:
            existentes += 1
            caminho = os.path.join(pasta, f'{existentes}.jpg')
            cv2.imwrite(caminho, rosto)
            salvos += 1

    return salvos


def primeira_foto_perfil(tipo, pessoa_id):
    """Retorna o caminho relativo (para servir na web) da primeira foto salva, se existir."""
    pasta = _pessoa_dir(tipo, pessoa_id)
    arquivos = sorted([f for f in os.listdir(pasta) if f.endswith('.jpg')])
    if arquivos:
        return f'faces/{tipo}_{pessoa_id}/{arquivos[0]}'
    return None


def treinar_modelo(db_path):
    """
    Lê todas as fotos salvas em static/faces/<tipo>_<id>/ e treina o
    reconhecedor LBPH do OpenCV. Atualiza a tabela face_labels com o
    mapeamento label numérico -> (tipo, pessoa_id).
    """
    conn = sqlite3.connect(db_path)
    conn.execute('DELETE FROM face_labels')

    faces = []
    labels = []
    label_atual = 0

    if not os.path.isdir(FACES_DIR):
        os.makedirs(FACES_DIR, exist_ok=True)

    for pasta_pessoa in sorted(os.listdir(FACES_DIR)):
        caminho_pasta = os.path.join(FACES_DIR, pasta_pessoa)
        if not os.path.isdir(caminho_pasta):
            continue
        try:
            tipo, pessoa_id = pasta_pessoa.rsplit('_', 1)
            pessoa_id = int(pessoa_id)
        except ValueError:
            continue

        fotos = [f for f in os.listdir(caminho_pasta) if f.endswith('.jpg')]
        if not fotos:
            continue

        conn.execute('INSERT INTO face_labels (label, tipo, pessoa_id) VALUES (?, ?, ?)',
                      (label_atual, tipo, pessoa_id))

        for foto in fotos:
            img = cv2.imread(os.path.join(caminho_pasta, foto), cv2.IMREAD_GRAYSCALE)
            if img is not None:
                img = cv2.resize(img, FACE_SIZE)
                faces.append(img)
                labels.append(label_atual)

        label_atual += 1

    conn.commit()
    conn.close()

    if not faces:
        # remove modelo antigo se não há mais rostos cadastrados
        if os.path.exists(MODEL_PATH):
            os.remove(MODEL_PATH)
        return 0

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.train(faces, np.array(labels))
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    recognizer.save(MODEL_PATH)
    return len(faces)


def reconhecer(img_bgr, db_path):
    """
    Tenta identificar a pessoa na imagem.
    Retorna dict: {'encontrado': bool, 'tipo':..., 'pessoa_id':..., 'confianca':...}
    ou {'encontrado': False, 'motivo': 'sem_rosto'|'sem_modelo'|'desconhecido'}
    """
    if not os.path.exists(MODEL_PATH):
        return {'encontrado': False, 'motivo': 'sem_modelo'}

    rosto = detectar_rosto(img_bgr)
    if rosto is None:
        return {'encontrado': False, 'motivo': 'sem_rosto'}

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(MODEL_PATH)
    label, confianca = recognizer.predict(rosto)

    if confianca > CONFIANCA_MAXIMA:
        return {'encontrado': False, 'motivo': 'desconhecido', 'confianca': float(confianca)}

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    row = conn.execute('SELECT tipo, pessoa_id FROM face_labels WHERE label = ?', (label,)).fetchone()
    conn.close()

    if not row:
        return {'encontrado': False, 'motivo': 'desconhecido', 'confianca': float(confianca)}

    return {
        'encontrado': True,
        'tipo': row['tipo'],
        'pessoa_id': row['pessoa_id'],
        'confianca': float(confianca)
    }


def decode_base64_image(b64str):
    return _decode_base64_image(b64str)
