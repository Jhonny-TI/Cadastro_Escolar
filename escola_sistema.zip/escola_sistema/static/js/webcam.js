/**
 * Utilitário de webcam reutilizável para captura de fotos de rosto.
 * Uso: WebcamCapturer.init({video, canvas, btnLigar, btnCapturar, galeria, hiddenInput})
 */
const WebcamCapturer = (function () {
    let stream = null;
    let capturas = [];

    function init(cfg) {
        const video = document.getElementById(cfg.video);
        const canvas = document.getElementById(cfg.canvas);
        const btnLigar = document.getElementById(cfg.btnLigar);
        const btnCapturar = document.getElementById(cfg.btnCapturar);
        const galeria = document.getElementById(cfg.galeria);
        const hiddenInput = document.getElementById(cfg.hiddenInput);

        btnLigar.addEventListener('click', async () => {
            try {
                stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
                video.srcObject = stream;
                video.play();
                btnCapturar.disabled = false;
                btnLigar.textContent = 'Câmera ligada';
                btnLigar.disabled = true;
            } catch (err) {
                alert('Não foi possível acessar a câmera: ' + err.message);
            }
        });

        btnCapturar.addEventListener('click', () => {
            const ctx = canvas.getContext('2d');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
            capturas.push(dataUrl);
            hiddenInput.value = JSON.stringify(capturas);

            const img = document.createElement('img');
            img.src = dataUrl;
            img.className = 'thumb-capturada me-2 mb-2';
            galeria.appendChild(img);
        });
    }

    function getCapturas() {
        return capturas;
    }

    function pararCamera() {
        if (stream) {
            stream.getTracks().forEach(t => t.stop());
        }
    }

    return { init, getCapturas, pararCamera };
})();
