-- Schema do Sistema de Gestão Escolar

CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    senha_hash TEXT NOT NULL,
    nome TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'admin'
);

CREATE TABLE IF NOT EXISTS turmas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    ano_letivo INTEGER NOT NULL,
    turno TEXT
);

CREATE TABLE IF NOT EXISTS disciplinas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    carga_horaria INTEGER
);

CREATE TABLE IF NOT EXISTS professores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cpf TEXT UNIQUE,
    registro TEXT UNIQUE,
    email TEXT,
    telefone TEXT,
    especialidade TEXT,
    data_nascimento TEXT,
    foto_path TEXT,
    data_cadastro TEXT DEFAULT CURRENT_TIMESTAMP,
    ativo INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS alunos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cpf TEXT UNIQUE,
    matricula TEXT UNIQUE,
    data_nascimento TEXT,
    email TEXT,
    telefone TEXT,
    responsavel TEXT,
    telefone_responsavel TEXT,
    turma_id INTEGER,
    foto_path TEXT,
    data_cadastro TEXT DEFAULT CURRENT_TIMESTAMP,
    ativo INTEGER DEFAULT 1,
    FOREIGN KEY (turma_id) REFERENCES turmas(id)
);

CREATE TABLE IF NOT EXISTS professor_disciplina (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    professor_id INTEGER,
    disciplina_id INTEGER,
    turma_id INTEGER,
    FOREIGN KEY(professor_id) REFERENCES professores(id),
    FOREIGN KEY(disciplina_id) REFERENCES disciplinas(id),
    FOREIGN KEY(turma_id) REFERENCES turmas(id)
);

CREATE TABLE IF NOT EXISTS matriculas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    aluno_id INTEGER,
    disciplina_id INTEGER,
    turma_id INTEGER,
    ano_letivo INTEGER,
    FOREIGN KEY(aluno_id) REFERENCES alunos(id),
    FOREIGN KEY(disciplina_id) REFERENCES disciplinas(id),
    FOREIGN KEY(turma_id) REFERENCES turmas(id)
);

CREATE TABLE IF NOT EXISTS presencas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    aluno_id INTEGER,
    disciplina_id INTEGER,
    data TEXT,
    presente INTEGER,
    metodo TEXT DEFAULT 'manual',
    FOREIGN KEY(aluno_id) REFERENCES alunos(id),
    FOREIGN KEY(disciplina_id) REFERENCES disciplinas(id)
);

CREATE TABLE IF NOT EXISTS notas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    aluno_id INTEGER,
    disciplina_id INTEGER,
    bimestre INTEGER,
    nota REAL,
    ano_letivo INTEGER,
    FOREIGN KEY(aluno_id) REFERENCES alunos(id),
    FOREIGN KEY(disciplina_id) REFERENCES disciplinas(id)
);

CREATE TABLE IF NOT EXISTS face_labels (
    label INTEGER PRIMARY KEY AUTOINCREMENT,
    tipo TEXT NOT NULL,
    pessoa_id INTEGER NOT NULL
);
