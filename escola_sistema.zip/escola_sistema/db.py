import sqlite3
import os
from flask import g, current_app

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'instance', 'escola.db')


def get_db():
    if 'db' not in g:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys = ON')
    return g.db


def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    schema_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'schema.sql')
    with open(schema_path, 'r', encoding='utf-8') as f:
        conn.executescript(f.read())
    conn.commit()

    # cria usuário admin padrão se não existir
    cur = conn.execute("SELECT COUNT(*) FROM usuarios")
    if cur.fetchone()[0] == 0:
        from werkzeug.security import generate_password_hash
        conn.execute(
            "INSERT INTO usuarios (username, senha_hash, nome, role) VALUES (?, ?, ?, ?)",
            ('admin', generate_password_hash('admin123'), 'Administrador', 'admin')
        )
        conn.commit()
    conn.close()


def init_app(app):
    app.teardown_appcontext(close_db)
    with app.app_context():
        if not os.path.exists(DB_PATH):
            init_db()
        else:
            # garante que as tabelas existam mesmo se o arquivo já existir vazio
            conn = sqlite3.connect(DB_PATH)
            schema_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'schema.sql')
            with open(schema_path, 'r', encoding='utf-8') as f:
                conn.executescript(f.read())
            conn.commit()
            cur = conn.execute("SELECT COUNT(*) FROM usuarios")
            if cur.fetchone()[0] == 0:
                from werkzeug.security import generate_password_hash
                conn.execute(
                    "INSERT INTO usuarios (username, senha_hash, nome, role) VALUES (?, ?, ?, ?)",
                    ('admin', generate_password_hash('admin123'), 'Administrador', 'admin')
                )
                conn.commit()
            conn.close()
